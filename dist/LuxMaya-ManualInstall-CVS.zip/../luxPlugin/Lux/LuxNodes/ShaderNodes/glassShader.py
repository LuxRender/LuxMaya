# ------------------------------------------------------------------------------
# Lux material shader node for Maya
#
# by Doug Hammond 05/2008
#
# This file is licensed under the GPL
# http://www.gnu.org/licenses/gpl-3.0.txt
#
# $Id: glassShader.py,v 1.1 2008/06/08 12:57:41 dougal2 Exp $
#
# ------------------------------------------------------------------------------
#
# Lux material shader node for Maya ( glass attributes )
#
# ------------------------------------------------------------------------------

from maya import OpenMaya
from maya import OpenMayaMPx

from Lux.LuxNodes.ShaderNode import ShaderNode
from Lux.LuxNodes.LuxNode import ShaderColorAttribute
from Lux.LuxNodes.LuxNode import ShaderFloatAttribute

class glassShader(OpenMayaMPx.MPxNode, ShaderNode):
    """
    Glass fragment of luxshader
    """
    
    # glass
    kr      =    OpenMaya.MObject()    # color
    kt      =    OpenMaya.MObject()    # color
    index   =    OpenMaya.MObject()    # float
    cauchyb =    OpenMaya.MObject()    # float

    def __init__(self):
        OpenMayaMPx.MPxNode.__init__(self)
        
        # Export attributes
        self.attributes = {}
        self.luxType = "glass"
        self.attributes['Kr']      = ShaderColorAttribute('glassKr')
        self.attributes['Kt']      = ShaderColorAttribute('glassKt')
        self.attributes['index']   = ShaderFloatAttribute('glassIndex')
        self.attributes['cauchyb'] = ShaderFloatAttribute('glassCauchyB')

    @staticmethod
    def shaderInitializer():
        try:
            # surface reflectivity
            glassShader.kr = glassShader.makeColor("glassKr", "gkr")

            # surface transmissivity
            glassShader.kt = glassShader.makeColor("glassKt", "gkt")

            # IOR
            glassShader.index = glassShader.makeFloat("glassIndex", "gi", 1.5)

            # cauchy b
            glassShader.cauchyb = glassShader.makeFloat("glassCauchyB", "gcb", 0.0)

        except:
            OpenMaya.MGlobal.displayError("Failed to create glass attributes\n")
            raise
        